import express from 'express';
import User from '../models/User.js';
import { requireAuth, requireRole } from '../middleware/auth.js';

const router = express.Router();

// Admin only
router.use(requireAuth, requireRole(['Admin']));

router.get('/', async (req,res)=>{
  const users = await User.find().select('-password').sort({createdAt:-1});
  res.json(users);
});

router.patch('/:id', async (req,res)=>{
  const { role, active } = req.body;
  const user = await User.findByIdAndUpdate(req.params.id, { role, active }, { new: true }).select('-password');
  res.json(user);
});

export default router;
