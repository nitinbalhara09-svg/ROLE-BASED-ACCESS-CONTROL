import express from 'express';
import Post from '../models/Post.js';
import { requireAuth, requireRole, ownsOrAdmin } from '../middleware/auth.js';

const router = express.Router();

// list + create
router.get('/', requireAuth, async (req,res)=>{
  const q = {};
  const posts = await Post.find(q).sort({createdAt:-1}).limit(100).lean();
  res.json(posts);
});

router.post('/', requireAuth, requireRole(['Admin','Editor']), async (req,res)=>{
  const { title, body } = req.body;
  const p = await Post.create({ title, body, authorId: req.user.id });
  res.json(p);
});

router.get('/:id', requireAuth, async (req,res)=>{
  const p = await Post.findById(req.params.id);
  if(!p) return res.status(404).json({message:'Not found'});
  res.json(p);
});

router.put('/:id', requireAuth, ownsOrAdmin(async (req)=>{
  const p = await Post.findById(req.params.id);
  return p?.authorId;
}), async (req,res)=>{
  const { title, body } = req.body;
  const p = await Post.findByIdAndUpdate(req.params.id, { title, body }, { new: true });
  res.json(p);
});

router.delete('/:id', requireAuth, ownsOrAdmin(async (req)=>{
  const p = await Post.findById(req.params.id);
  return p?.authorId;
}), async (req,res)=>{
  await Post.findByIdAndDelete(req.params.id);
  res.json({ ok:true });
});

export default router;
