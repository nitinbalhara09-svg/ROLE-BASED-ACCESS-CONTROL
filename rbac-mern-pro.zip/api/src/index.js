import 'dotenv/config';
import express from 'express';
import mongoose from 'mongoose';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import postRoutes from './routes/posts.js';

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors({
  origin: process.env.WEB_ORIGIN || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json());
app.use(cookieParser());

app.get('/api/health', (req,res)=> res.json({ok:true, time: new Date().toISOString()}));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/posts', postRoutes);

mongoose.connect(process.env.MONGO_URI).then(()=>{
  console.log('MongoDB connected');
  app.listen(PORT, ()=> console.log('API running on http://localhost:'+PORT));
}).catch(err=>{
  console.error('Mongo connection error', err.message);
  process.exit(1);
});
