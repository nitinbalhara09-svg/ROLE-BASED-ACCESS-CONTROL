import React, { useEffect, useState, createContext, useContext } from 'react';
import { Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import { api } from './lib/api';

const AuthCtx = createContext(null);
const useAuth = ()=> useContext(AuthCtx);

function Private({ children }){
  const { user, loading } = useAuth();
  if(loading) return <div className="p-6">Loading...</div>;
  if(!user) return <Navigate to="/login" replace />;
  return children;
}

function RoleGate({ allow=[], children }){
  const { user } = useAuth();
  if(!user) return null;
  return allow.includes(user.role) ? children : <div className="p-6 text-sm text-red-600">You don't have permission.</div>;
}

function Layout({ children }){
  const { user, logout } = useAuth();
  return (
    <div className="min-h-screen grid grid-cols-[240px_1fr]">
      <aside className="bg-white border-r">
        <div className="p-4 font-bold">RBAC Dashboard</div>
        <nav className="p-2 space-y-1">
          <Link className="block px-3 py-2 hover:bg-slate-100 rounded" to="/">Overview</Link>
          <Link className="block px-3 py-2 hover:bg-slate-100 rounded" to="/posts">Posts</Link>
          <Link className="block px-3 py-2 hover:bg-slate-100 rounded" to="/users">Users</Link>
        </nav>
      </aside>
      <main className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="text-xl font-semibold">Welcome {user?.name}</div>
          <div className="flex items-center gap-2">
            <span className="text-xs px-2 py-1 bg-slate-200 rounded-full">{user?.role}</span>
            <button onClick={logout} className="text-sm px-3 py-1 bg-black text-white rounded">Logout</button>
          </div>
        </div>
        {children}
      </main>
    </div>
  );
}

function Dashboard(){
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  useEffect(()=>{
    (async ()=>{
      try{
        const posts = await api('/posts');
        setStats({ posts: posts.length });
      }catch(e){}
    })();
  },[]);
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow p-4">
          <div className="text-sm text-slate-500">Total Posts</div>
          <div className="text-3xl font-bold">{stats?.posts ?? '—'}</div>
        </div>
        <div className="bg-white rounded-xl shadow p-4">
          <div className="text-sm text-slate-500">Your Role</div>
          <div className="text-3xl font-bold">{user?.role}</div>
        </div>
        <div className="bg-white rounded-xl shadow p-4">
          <div className="text-sm text-slate-500">Status</div>
          <div className="text-3xl font-bold">Active</div>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow p-4">
        <div className="text-sm text-slate-500 mb-2">Activity (fake chart)</div>
        <div className="h-32 bg-gradient-to-r from-slate-100 to-slate-200 rounded" />
      </div>
    </div>
  );
}

function Posts(){
  const { user } = useAuth();
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ title:'', body:'' });

  const load = async()=> setList(await api('/posts'));
  useEffect(()=>{ load(); },[]);

  const createPost = async (e)=>{
    e.preventDefault();
    await api('/posts', { method:'POST', body: JSON.stringify(form) });
    setForm({ title:'', body:'' });
    load();
  };
  const remove = async (id)=>{
    await api('/posts/'+id, { method:'DELETE' });
    load();
  };

  return (
    <div className="grid grid-cols-2 gap-6">
      <div className="bg-white rounded-xl shadow p-4">
        <div className="font-semibold mb-2">All Posts</div>
        <ul className="space-y-2">
          {list.map(p=>(
            <li key={p._id} className="border rounded p-3">
              <div className="font-medium">{p.title}</div>
              <div className="text-sm text-slate-600">{p.body}</div>
              {(user.role==='Admin' || String(p.authorId)===user.id) && (
                <button onClick={()=>remove(p._id)} className="mt-2 text-xs px-2 py-1 bg-red-600 text-white rounded">Delete</button>
              )}
            </li>
          ))}
        </ul>
      </div>

      <RoleGate allow={['Admin','Editor']}>
        <div className="bg-white rounded-xl shadow p-4">
          <div className="font-semibold mb-2">Create Post</div>
          <form onSubmit={createPost} className="space-y-2">
            <input className="w-full border rounded px-3 py-2" placeholder="Title" value={form.title} onChange={e=>setForm({...form, title:e.target.value})} />
            <textarea className="w-full border rounded px-3 py-2" placeholder="Body" value={form.body} onChange={e=>setForm({...form, body:e.target.value})} />
            <button className="px-3 py-2 bg-black text-white rounded">Save</button>
          </form>
        </div>
      </RoleGate>
    </div>
  );
}

function Users(){
  const [users, setUsers] = useState([]);
  const load = async()=> setUsers(await api('/users'));
  useEffect(()=>{ load(); },[]);
  const update = async (id, patch)=>{
    await api('/users/'+id, { method:'PATCH', body: JSON.stringify(patch) });
    load();
  };
  return (
    <RoleGate allow={['Admin']}>
      <div className="bg-white rounded-xl shadow p-4">
        <div className="font-semibold mb-2">Manage Users</div>
        <table className="w-full text-sm">
          <thead><tr className="text-left">
            <th className="py-2">Name</th><th>Email</th><th>Role</th><th>Status</th><th></th>
          </tr></thead>
          <tbody>
            {users.map(u=>(
              <tr key={u._id} className="border-t">
                <td className="py-2">{u.name}</td>
                <td>{u.email}</td>
                <td>
                  <select value={u.role} onChange={e=>update(u._id, { role:e.target.value })} className="border rounded px-2 py-1">
                    {['Admin','Editor','Viewer'].map(r=><option key={r} value={r}>{r}</option>)}
                  </select>
                </td>
                <td>
                  <button onClick={()=>update(u._id, { active: !u.active })} className={'px-2 py-1 rounded '+(u.active?'bg-green-600 text-white':'bg-slate-200')}>
                    {u.active?'Active':'Disabled'}
                  </button>
                </td>
                <td></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </RoleGate>
  );
}

function Login(){
  const nav = useNavigate();
  const { setUser } = useAuth();
  const [form, setForm] = useState({ email:'', password:'' });
  const submit = async (e)=>{
    e.preventDefault();
    const res = await api('/auth/login', { method:'POST', body: JSON.stringify(form) });
    setUser({ ...res.user, id: res.user.id });
    nav('/');
  };
  return (
    <div className="h-screen grid place-items-center">
      <form onSubmit={submit} className="w-[360px] bg-white rounded-xl shadow p-6 space-y-3">
        <div className="text-xl font-semibold">Sign in</div>
        <input className="w-full border rounded px-3 py-2" placeholder="Email" value={form.email} onChange={e=>setForm({...form, email:e.target.value})}/>
        <input className="w-full border rounded px-3 py-2" placeholder="Password" type="password" value={form.password} onChange={e=>setForm({...form, password:e.target.value})}/>
        <button className="w-full px-3 py-2 bg-black text-white rounded">Login</button>
        <div className="text-xs text-slate-500">Use admin@demo.com, editor@demo.com, viewer@demo.com — password: <b>pass123</b></div>
      </form>
    </div>
  );
}

export default function App(){
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(()=>{
    (async ()=>{
      try{ const me = await api('/auth/me'); setUser({ ...me, id: me._id }); }catch(e){}
      setLoading(false);
    })();
  },[]);

  const logout = async ()=>{ await api('/auth/logout', { method:'POST' }); setUser(null); };

  return (
    <AuthCtx.Provider value={{ user, setUser, loading, logout }}>
      <Routes>
        <Route path="/login" element={<Login/>} />
        <Route path="/" element={<Private><Layout><Dashboard/></Layout></Private>} />
        <Route path="/posts" element={<Private><Layout><Posts/></Layout></Private>} />
        <Route path="/users" element={<Private><Layout><Users/></Layout></Private>} />
      </Routes>
    </AuthCtx.Provider>
  );
}
